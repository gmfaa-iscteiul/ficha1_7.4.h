import org.junit.runner.JUnitCore;

public class complemento {

	public static void main(String[] args) {
		JUnitCore.main("complementoTest");
	}
}
